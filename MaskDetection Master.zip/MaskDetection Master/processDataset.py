import os
import cv2
from tqdm import tqdm
import xml.etree.ElementTree as ET

def get_objects(xml_file):
  annotation = ET.parse(xml_file)
  root = annotation.getroot()

  objects = []
  for obj in root.findall('object'):
    new_object = {'name': obj.find('name').text}
    bbox_tree = obj.find('bndbox')
    new_object['bbox'] = (int(bbox_tree.find('xmin').text), 
                          int(bbox_tree.find('ymin').text), 
                          int(bbox_tree.find('xmax').text), 
                          int(bbox_tree.find('ymax').text),
                          )
    # print(new_object)
    objects.append(new_object)
    
  return objects

imagePath = "Dataset/images"
annotationPath = "Dataset/annotations"

dirs = os.listdir(imagePath)

for imageName in tqdm(dirs):
    image = cv2.imread(os.path.join(imagePath, imageName))
    info = get_objects(os.path.join(annotationPath, imageName.replace("png", "xml")))
    for obj in info:
        box = obj["bbox"]
        maskStatus = obj["name"]
        
        xMean = (box[0] + box[2])/2
        yMean = (box[1] + box[3])/2
        wMax = box[2] - box[0]
        hMax = box[3] - box[1]
        size = max(wMax, hMax)/2
        x1, y1, x2, y2 = xMean - size, yMean - size, xMean + size, yMean + size
        
        x1 = max(0, x1)
        y1 = max(0, y1)
        
        croppedFace = image[int(y1):int(y2), int(x1):int(x2)]
        croppedFace = cv2.resize(croppedFace, (128, 128))
        if maskStatus == "with_mask":
            cv2.imwrite(os.path.join("Dataset/Images/WithMask", imageName), croppedFace)
        else:
            cv2.imwrite(os.path.join("Dataset/Images/WithoutMask", imageName), croppedFace)