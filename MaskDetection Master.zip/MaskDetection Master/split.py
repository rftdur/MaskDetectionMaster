import os
import random
import shutil
from tqdm import tqdm

wPath = "Dataset/Images/WithMask"
woPath = "Dataset/Images/WithoutMask"

wDirs = os.listdir(wPath)
woDirs = os.listdir(woPath)

random.shuffle(wDirs)
random.shuffle(woDirs)

wLen = int(len(wDirs)*0.05)
woLen = int(len(woDirs)*0.05)

for i in tqdm(wDirs[:wLen]):
    shutil.copyfile(os.path.join(wPath, i), os.path.join("Dataset/Test/WithMask", i))

for i in tqdm(wDirs[wLen:]):
    shutil.copyfile(os.path.join(wPath, i), os.path.join("Dataset/Train/WithMask", i))

for i in tqdm(woDirs[:woLen]):
    shutil.copyfile(os.path.join(woPath, i), os.path.join("Dataset/Test/WithoutMask", i))

for i in tqdm(woDirs[woLen:]):
    shutil.copyfile(os.path.join(woPath, i), os.path.join("Dataset/Train/WithoutMask", i))