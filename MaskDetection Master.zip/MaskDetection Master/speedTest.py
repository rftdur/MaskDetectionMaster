from multiprocessing import dummy
from time import time

import torch
import torch.nn as nn
from torchvision import models

dummyInput = torch.randn((1, 3, 224, 224))
devices = ["cuda", "cpu"]
modelList = ["r18", "r34", "r50", "r101", "r152"]

for device in devices:
    dummyInput = dummyInput.to(device)
    for modelName in modelList:
        
        # Load Model
        if modelName == "r18":
            model = models.resnet18()
            model.fc = nn.Sequential(nn.Linear(512, 2))
        elif modelName == "r34":
            model = models.resnet34()
            model.fc = nn.Sequential(nn.Linear(512, 2))
        elif modelName == "r50":
            model = models.resnet50()
            model.fc = nn.Sequential(nn.Linear(2048, 2))
        elif modelName == "r101":
            model = models.resnet101()
            model.fc = nn.Sequential(nn.Linear(2048, 2))
        elif modelName == "r152":
            model = models.resnet152()
            model.fc = nn.Sequential(nn.Linear(2048, 2))
        
        model.to(device)
        
        # Inference
        ## Warmup
        for _ in range(20):
            model(dummyInput)
            
        s = time()
        for _ in range(100):
            model(dummyInput)
        e = time()
        
        print("[Device: %s] - [Model: %s] - [FPS: %s]" % (device, modelName, round(1/((e - s)/100), 3)))